#' AUC-based Variable Selection with Sparsity Penalty
#' @description This example demonstrates using the \code{geneOptimize} package to 
#' perform variable selection for a logistic regression model, maximizing 
#' the Area Under the ROC Curve (AUC) while applying a sparsity penalty.
#' @name example_auc_selection
#' @examples
#' \dontrun{
#' library(geneOptimize)
#' library(yardstick)
#' 
#' # 1. Generate Synthetic Classification Data
#' set.seed(42)
#' n <- 200
#' p <- 15
#' X <- matrix(rnorm(n * p), n, p)
#' colnames(X) <- paste0("V", 1:p)
#' 
#' # Only V1, V3, and V5 affect the outcome
#' logits <- 1.5 * X[,1] - 1.2 * X[,3] + 0.8 * X[,5]
#' probs <- 1 / (1 + exp(-logits))
#' y <- as.factor(ifelse(runif(n) < probs, "Class1", "Class0"))
#' df <- data.frame(y = y, X)
#' 
#' # 2. Define Penalized AUC Fitness Function
#' fitness_sparse_auc <- function(genes, penalty = 0.01) {
#'   num_selected <- sum(genes)
#'   if (num_selected == 0) return(0)
#'   
#'   selected_vars <- colnames(X)[which(genes == 1)]
#'   formula_str <- paste("y ~", paste(selected_vars, collapse = " + "))
#'   
#'   model_res <- tryCatch({
#'     model <- glm(as.formula(formula_str), data = df, family = binomial)
#'     preds <- predict(model, type = "response")
#'     eval_df <- data.frame(truth = y, prob = preds)
#'     roc_res <- yardstick::roc_auc(eval_df, truth = truth, prob, event_level = "second")
#'     return(roc_res$.estimate - (penalty * num_selected))
#'   }, error = function(e) return(0))
#' }
#' 
#' # 3. Execute GA
#' results <- run_ga(
#'   fitness_fn = fitness_sparse_auc,
#'   n_genes = p,
#'   pop_size = 50,
#'   generations = 40,
#'   type = "binary",
#'   penalty = 0.01
#' )
#' 
#' # 4. Review Results
#' print(results)
#' print(colnames(X)[which(results$best_chromosome == 1)])
#' }
NULL
